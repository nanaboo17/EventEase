package eventease;

public class EventEase {
    public static void main(String[] args) {
        EventScheduleDB eventDB = new EventScheduleDB();
        
        System.out.println("Adding Event...");
        eventDB.addEvent("Tech Expo", "Technology Showcase", "2024-08-16", "10:00 AM", 1);
        
        System.out.println("\nDisplaying Events:");
        eventDB.displayEvents();
        
        System.out.println("\nUpdating Event ID 1...");
        eventDB.editEvent(1, "Tech Expo 2024", "Updated Showcase", "2024-08-20", "11:00 AM", 2);
        
        System.out.println("\nEvents After Update:");
        eventDB.displayEvents();
        
        System.out.println("\nDeleting Event ID 1...");
        eventDB.deleteEvent(1);
        
        System.out.println("\nEvents After Deletion:");
        eventDB.displayEvents();
    }
}
