/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;
import java.util.Date;

/**
 *
 * @author acer
 */

public class EventSchedule extends EventType {
    private Date eventDate;
    private String eventTime;

    public EventSchedule(String eventName, String description, Date eventDate, String eventTime) {
        super(eventName, description);
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }

    public void addEvent(Date date, String time) {
        this.eventDate = date;
        this.eventTime = time;
        System.out.println("Event added: " + eventName + " on " + eventDate + " at " + eventTime);
    }

    public void editEvent(Date date, String time) {
        this.eventDate = date;
        this.eventTime = time;
        System.out.println("Event edited to: " + eventName + " on " + eventDate + " at " + eventTime);
    }

    public void removeEvent() {
        System.out.println("Event " + eventName + " removed.");
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Event: " + eventName + ", Description: " + description + ", Date: " + eventDate + ", Time: " + eventTime);
    }

    String getEventTime() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getEventDate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int getEventID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

