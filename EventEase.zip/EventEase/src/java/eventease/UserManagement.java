/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */
public class UserManagement {
    private int userID;
    private String username;
    private String password;
    private String role; // "admin" or "organizer"

    public UserManagement(int userID, String username, String password, String role) {
        this.userID = userID;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public void addUser() {
        System.out.println("User " + username + " added with role " + role);
    }

    public void editUser(String newUsername, String newPassword, String newRole) {
        this.username = newUsername;
        this.password = newPassword;
        this.role = newRole;
        System.out.println("User updated: " + username + ", Role: " + role);
    }

    public void deleteUser() {
        System.out.println("User " + username + " deleted.");
    }

    public boolean login(String inputUsername, String inputPassword) {
        if (this.username.equals(inputUsername) && this.password.equals(inputPassword)) {
            System.out.println("Login successful for " + username);
            return true;
        } else {
            System.out.println("Login failed for " + username);
            return false;
        }
    }
}

