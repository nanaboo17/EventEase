/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */
public interface BookingSystem {
    void bookTicket(int ticketID);
    void cancelBooking(int ticketID);
    boolean checkAvailability();
}

