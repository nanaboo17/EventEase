package eventease;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EventScheduleDB {
    // CREATE (Add Event)
    public void addEvent(String eventName, String description, String date, String time, int venueID) {
        String query = "INSERT INTO Events (eventName, description, eventDate, eventTime, venueID) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, eventName);
            stmt.setString(2, description);
            stmt.setString(3, date);
            stmt.setString(4, time);
            stmt.setInt(5, venueID);
            stmt.executeUpdate();
            System.out.println("Event successfully added to the database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // READ (Display Events)
    public void displayEvents() {
        String query = "SELECT * FROM Events";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("Event ID: " + rs.getInt("eventID"));
                System.out.println("Event Name: " + rs.getString("eventName"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Date: " + rs.getDate("eventDate"));
                System.out.println("Time: " + rs.getString("eventTime"));
                System.out.println("------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // UPDATE (Edit Event)
    public void editEvent(int eventID, String newName, String newDesc, String newDate, String newTime, int newVenue) {
        String query = "UPDATE Events SET eventName=?, description=?, eventDate=?, eventTime=?, venueID=? WHERE eventID=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newName);
            stmt.setString(2, newDesc);
            stmt.setString(3, newDate);
            stmt.setString(4, newTime);
            stmt.setInt(5, newVenue);
            stmt.setInt(6, eventID);
            stmt.executeUpdate();
            System.out.println("Event updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // DELETE (Remove Event)
    public void deleteEvent(int eventID) {
        String query = "DELETE FROM Events WHERE eventID=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventID);
            stmt.executeUpdate();
            System.out.println("Event deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
