/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */
public class Venue {
    private int venueID;
    private String location;
    int capacity;

    public Venue(int venueID, String location, int capacity) {
        this.venueID = venueID;
        this.location = location;
        this.capacity = capacity;
    }

    public void addVenue() {
        System.out.println("Venue " + location + " added with capacity " + capacity);
    }

    public void editVenue(String newLocation, int newCapacity) {
        this.location = newLocation;
        this.capacity = newCapacity;
        System.out.println("Venue updated: " + location + ", Capacity: " + capacity);
    }

    public void removeVenue() {
        System.out.println("Venue " + location + " removed.");
    }

    // Getter untuk location
    public String getLocation() {
        return location;
    }

    // Getter untuk capacity
    public int getCapacity() {
        return capacity;
    }
}



