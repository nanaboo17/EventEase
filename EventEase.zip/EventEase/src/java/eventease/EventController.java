package eventease;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EventController")
public class EventController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Menentukan tipe konten respons
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        // Mengambil parameter dari form
        String action = request.getParameter("action");
        String eventName = request.getParameter("eventName");
        String description = request.getParameter("description");
        String eventDate = request.getParameter("eventDate");
        String eventTime = request.getParameter("eventTime");
        int venueID = Integer.parseInt(request.getParameter("venueID"));

        // Mengecek aksi yang diterima (addEvent, editEvent, dll.)
        if ("addEvent".equals(action)) {
            // Menghubungkan ke database
            Connection conn = null;
            PreparedStatement stmt = null;

            try {
                // Koneksi ke database MySQL
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventease", "root", ""); // Ganti dengan password yang sesuai
                String sql = "INSERT INTO events (eventName, description, eventDate, eventTime, venueID) VALUES (?, ?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                
                // Menyisipkan data event ke dalam database
                stmt.setString(1, eventName);
                stmt.setString(2, description);
                stmt.setString(3, eventDate);
                stmt.setString(4, eventTime);
                stmt.setInt(5, venueID);

                // Menjalankan query
                int rowsAffected = stmt.executeUpdate();
                
                // Mengecek apakah data berhasil ditambahkan
                if (rowsAffected > 0) {
                    out.println("<h2>Event Berhasil Ditambahkan!</h2>");
                    out.println("<p>Nama Event: " + eventName + "</p>");
                    out.println("<p>Deskripsi: " + description + "</p>");
                    out.println("<p>Tanggal: " + eventDate + ", Waktu: " + eventTime + "</p>");
                } else {
                    out.println("<h2>Gagal Menambahkan Event!</h2>");
                }
            } catch (Exception e) {
                // Menangani error jika terjadi kesalahan
                out.println("<h2>Terjadi Kesalahan: " + e.getMessage() + "</h2>");
                e.printStackTrace();
            } finally {
                // Menutup koneksi dan statement setelah selesai
                try {
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            out.println("<h2>Aksi Tidak Dikenali!</h2>");
        }
    }
}
