/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */
public class Participant {
    private int participantID;
    private String name;
    private String email;

    public Participant(int participantID, String name, String email) {
        this.participantID = participantID;
        this.name = name;
        this.email = email;
    }

    public void registerParticipant() {
        System.out.println("Participant " + name + " registered successfully.");
    }

    public void editParticipantInfo(String name, String email) {
        this.name = name;
        this.email = email;
        System.out.println("Participant info updated: " + name + ", " + email);
    }

    public void removeParticipant() {
        System.out.println("Participant " + name + " removed.");
    }
}


