/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */
public abstract class EventType {
    protected String eventName;
    protected String description;

    public EventType(String eventName, String description) {
        this.eventName = eventName;
        this.description = description;
    }

    public abstract void displayEventDetails();

    public void setEventName(String name) {
        this.eventName = name;
    }

    public String getEventName() {
        return eventName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}

