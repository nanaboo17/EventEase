/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventease;

/**
 *
 * @author acer
 */

public class Ticket implements BookingSystem {
    private int ticketID;
    private String ticketType;
    private double price;
    private boolean available;

    public Ticket(int ticketID, String ticketType, double price) {
        this.ticketID = ticketID;
        this.ticketType = ticketType;
        this.price = price;
        this.available = true; // Default to available
    }

    @Override
    public void bookTicket(int ticketID) {
        if (available) {
            available = false;
            System.out.println("Ticket ID " + ticketID + " booked successfully.");
        } else {
            System.out.println("Ticket ID " + ticketID + " is not available.");
        }
    }

    @Override
    public void cancelBooking(int ticketID) {
        if (!available) {
            available = true;
            System.out.println("Booking for Ticket ID " + ticketID + " canceled.");
        } else {
            System.out.println("Ticket ID " + ticketID + " is already available.");
        }
    }

    @Override
    public boolean checkAvailability() {
        return available;
    }
}

